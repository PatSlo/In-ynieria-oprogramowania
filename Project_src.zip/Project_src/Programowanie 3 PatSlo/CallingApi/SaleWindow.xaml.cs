﻿using System;
using System.Windows;
using System.Net.Http;
using System.Collections.Generic;
using CallingApi.Models;
using System.Windows.Input;
using Newtonsoft.Json;
using System.Runtime.CompilerServices;

namespace CallingApi
{
    /// <summary>
    /// Interaction logic for SaleWindow.xaml
    /// </summary>
    public partial class SaleWindow : Window
    {
        HttpClient client = new HttpClient();
        private Game game;
        public SaleWindow(Game selectedgames)
        {
            client.BaseAddress = new Uri("https://localhost:7195/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            if (selectedgames != null)
            {
                game = selectedgames;
            }
            else
            {
                // Jeśli selectedGame jest null, możesz podjąć odpowiednie działania
                // np. wyświetlić komunikat o błędzie, zamknąć okno, itp.
                MessageBox.Show("Error: Selected game is null.");
                this.Close();  // Zamknięcie okna
            }
            InitializeComponent();
        }

        private async void SaveGame(Game game)
        {
            await client.PostAsJsonAsync("game", game);
        }

        private async void UpdateGame(Game game)
        {
            await client.PutAsJsonAsync("game/" + game.ID, game);
        }

        private void txtSale_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Sprawdzanie, czy wprowadzony tekst jest liczbą
            if (!int.TryParse(e.Text, out int result))
            {
                e.Handled = true; // Jeśli nie jest liczbą, zatrzymaj wprowadzanie tekstu
            }
            else
            {
                // Jeśli jest liczbą, sprawdź, czy mieści się w zakresie 1-100
                int enteredNumber = int.Parse(txtSale.Text + e.Text);
                if (enteredNumber < 1 || enteredNumber > 100)
                {
                    e.Handled = true; // Jeśli jest poza zakresem, zatrzymaj wprowadzanie tekstu
                }
            }
        }

        private async void btnSave_Click(object sender, RoutedEventArgs e)
        {
           // Game game = ((FrameworkElement)sender).DataContext as Game;
            // Pobierz wartość procentową z pola tekstowego
            if (int.TryParse(txtSale.Text, out int salePercentage))
         {
        // Sprawdź, czy jest w zakresie 1-100
         if (salePercentage >= 1 && salePercentage <= 100)
         {

            // Odejmij od ceny procent i zaktualizuj w bazie danych
            game.Price = game.Price - (game.Price * salePercentage / 100);

            if (game.ID == 0)
            {
                this.SaveGame(game);
                lblMessage.Content = "Game Saved";
            }
            else
            {
                this.UpdateGame(game);
                lblMessage.Content = "Game Updated";
            }
         }
        else
        {
            lblMessage.Content = "Please enter a valid sale percentage between 1 and 100.";
        }
        }
        else
        {
            lblMessage.Content = "Please enter a valid numeric value for the sale percentage.";
        } 
            this.Close();
        }       
    }
}
