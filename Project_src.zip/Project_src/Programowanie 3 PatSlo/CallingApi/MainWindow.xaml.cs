﻿using System.Windows;
using System.Net.Http;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using CallingApi.Models;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Input;

namespace CallingApi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HttpClient client = new HttpClient();
        public MainWindow()
        {
            client.BaseAddress = new Uri("https://localhost:7195/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void btnLoadGames_Click(object sender, RoutedEventArgs e)
        {
            this.GetGames();
        }

        private async void GetGames()
        {
            lblMessage.Content = "";

            var response = await client.GetStringAsync("game");
            var games = JsonConvert.DeserializeObject<List<Game>>(response);
            dgGame.DataContext = games;
        }

        private async void SaveGame(Game game)
        {
            await client.PostAsJsonAsync("game", game);
        }

        private async void UpdateGame(Game game)
        {
            await client.PutAsJsonAsync("game/"+ game.ID, game);
        }

        private async void DeleteGame(int ID )
        {
            await client.DeleteAsync("game/" + ID );
        }

        private void btnSaveGame_Click(object sender, RoutedEventArgs e)
        {
            var game = new Game()
            {
                ID = Convert.ToInt32(txtGameID.Text),
                Name = txtName.Text,
                Platform = txtPlatform.Text,
                Price = (float) Convert.ToDouble(txtPrice.Text)
            };

            if (game.ID==0)
             {
                this.SaveGame(game);
                 lblMessage.Content = "Game Saved";
             }
             else
             {
                 this.UpdateGame(game);
                 lblMessage.Content = "Game Updated";
             }

            txtGameID.Text = 0.ToString();
            txtName.Text = "";
            txtPlatform.Text = "";
            txtPrice.Text = 0.ToString();

        }

        private void btnSaleGame(object sender, RoutedEventArgs e)
        {
            Game selectedGame = ((FrameworkElement)sender).DataContext as Game;

            // Sprawdź, czy dane zostały prawidłowo pobrane
            if (selectedGame != null)
            {
                // Otwórz nowe okno i przekaz dane
                SaleWindow saleWindow = new SaleWindow(selectedGame);
                saleWindow.Show();
            }
            else
            {
                // Obsłuż sytuację, gdy nie można pobrać danych (może być null)
                MessageBox.Show("Błąd podczas pobierania danych produktu.");
            }
        }

        void btnEditGame(object sender, RoutedEventArgs e)
        {
            Game game = ((FrameworkElement)sender).DataContext as Game;
            txtGameID.Text = game.ID.ToString();
            txtName.Text = game.Name;
            txtPlatform.Text = game.Platform;
            txtPrice.Text = game.Price.ToString();
        }

        void btnDeleteGame(object sender, RoutedEventArgs e)
        {
            Game game = ((FrameworkElement)sender).DataContext as Game;
            this.DeleteGame(game.ID);
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex(@"^\d+(\,\d{0,2})?$");
            e.Handled = !regex.IsMatch((sender as TextBox).Text + e.Text);
        }
    }
}
