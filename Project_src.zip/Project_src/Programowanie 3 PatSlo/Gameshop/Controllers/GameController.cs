﻿using Gameshop.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gameshop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GameController : ControllerBase
    {
        private readonly GameContext _dbContext;
        public GameController(GameContext dbContext)
        {
            _dbContext = dbContext;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Game>>> GetGames()
        {
            if(_dbContext.Games == null)
            {
                return NotFound();
            }
            return await _dbContext.Games.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Game>> GetGame(int id)
        {
            if (_dbContext.Games == null)
            {
                return NotFound();
            }
            var game = await _dbContext.Games.FindAsync(id);
            if (game == null)
            {
                return NotFound();
            }
            return game;
        }

        [HttpPost]
        public async Task<ActionResult<Game>> PostGame(Game game)
        {
            _dbContext.Games.Add(game);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetGame), new { id = game.ID }, game);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutGame(int id, Game game)
        {
            if(id != game.ID)
            {
                return BadRequest();
            }
            _dbContext.Entry(game).State = EntityState.Modified;

            try
            {
                _dbContext.Entry(game).State = EntityState.Modified;
                await _dbContext.SaveChangesAsync();
            }
            catch(DbUpdateConcurrencyException)
            {
                if(!GameAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok(new { Message = "Game updated successfully", UpdatedGame = game });
        }

        private bool GameAvailable (int id)
        {
            return (_dbContext.Games?.Any(x=>x.ID == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGame(int id)
        {
            if(_dbContext.Games == null)
            {
                return NotFound();
            }

            var game = await _dbContext.Games.FindAsync(id);
            if(game == null)
            {
                return NotFound();
            }

            _dbContext.Games.Remove(game);

            await _dbContext.SaveChangesAsync();

            return Ok();
        }
    }
}
