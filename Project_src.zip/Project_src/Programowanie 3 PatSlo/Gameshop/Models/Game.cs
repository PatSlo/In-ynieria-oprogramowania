﻿namespace Gameshop.Models
{
    public class Game
    {
        public int ID { get; set; }
        public string? Name { get; set; }

        public string? Platform { get; set; }

        public float Price { get; set; }
    }
}
