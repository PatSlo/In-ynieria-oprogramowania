﻿using System.Windows;

namespace Programowanie_3_PatSlo
{
    /// <summary>
    /// Logika interakcji dla klasy L1Z4.xaml
    /// </summary>
    public partial class L1Z4 : Window
    {
        public L1Z4()
        {
            InitializeComponent();
        }
    }
}
