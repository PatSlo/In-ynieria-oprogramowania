﻿using System.Windows;

namespace Programowanie_3_PatSlo
{
    /// <summary>
    /// Logika interakcji dla klasy L1Z2.xaml
    /// </summary>
    public partial class L1Z2 : Window
    {
        public L1Z2()
        {
            InitializeComponent();
        }
    }
}
