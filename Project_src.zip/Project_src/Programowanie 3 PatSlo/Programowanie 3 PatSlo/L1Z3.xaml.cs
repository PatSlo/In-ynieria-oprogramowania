﻿using System.Windows;

namespace Programowanie_3_PatSlo
{
    /// <summary>
    /// Logika interakcji dla klasy L1Z3.xaml
    /// </summary>
    public partial class L1Z3 : Window
    {
        public L1Z3()
        {
            InitializeComponent();
        }
    }
}
